<?php
session_start();
// include("connection.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize user inputs to prevent SQL injection
    $myusername = mysqli_real_escape_string($db, $_POST['username']);
    $mypassword = mysqli_real_escape_string($db, $_POST['password']);

    // Query to check if the user exists
    $query = "SELECT id FROM adminlogin WHERE username = '$myusername' AND password = '$mypassword'";
    $result = mysqli_query($db, $query);
    $count = mysqli_num_rows($result);

    // If a user is found, set session variables and redirect to welcome page
    if ($count == 1) {
        $_SESSION['username'] = $myusername;
        $_SESSION['login_user'] = $myusername;
        header("location: welcome.php");
        exit();
    } else {
        $error = "Invalid Username or Password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login Page</title>
    <link rel="stylesheet" type="text/css" href="login.css">
</head>

<body bgcolor="#FFFFFF">

    <div align="center">
        <div style="width: 300px; border: solid 1px #333333;" align="left">
            <div style="background-color:#333333; color:#FFFFFF; padding: 3px;"><b>Admin Login</b></div>

            <div style="margin: 30px">
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div style="font-size: 11px; color: #cc0000; margin-top: 10px;"><b><?php echo $error; ?></b></div><br>
                    <label for="uname"><b>Username</b></label><br>
                    <input type="text" name="username" class="box" placeholder="Enter your Name" required><br><br>
                    <label for="uname"><b>Password</b></label><br>
                    <input type="password" name="password" class="box" placeholder="Enter your Password" required><br><br>
                    <button type="submit" name="submit">Login</button><br>
                </form>
            </div>
        </div>
    </div>

</body>

</html>
