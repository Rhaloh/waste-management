<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "wms";

// Create connection
$db = new mysqli($servername, $username, $password, $database);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
} else {
    echo "Connected successfully to database: " . $database;
}

